------------------------------------------------------------------------

AsciiWorld version 01

------------------------------------------------------------------------

topic :

le but est de pouvoir aller chercher sur un serveur, les param�tres des images
d�pos�es.

Il faut donc faire communiquer nos machines, soit entre elles en r�seau local
(de Max vers Max, ou de Max vers processing et inversement),
soit avec un serveur distant (pour acc�der au site asciitunes) via internet.

------------------------------------------------------------------------

pour cela il faut installer de nouveaux objets dans les librairies de Max.
Ces fichiers vous les trouverez pour les utilisateurs de Mac dans le dossier
OSX et pour les utilisateurs de PC dans le dossier windows.

------------------------------------------------------------------------

voici une aide concernant la proc�dure � suivre :


Installation de nouveaux objets dans Max/MSP/jitter :

Attention :

un fichier poss�dant l'extension .mxe est un objet Max pour windows
(exemple : udpreceive.mxe)

un fichier poss�dant l'extension .mxo est un objet Max pour OSX
(exemple : udpreceive.mxo)

un fichier poss�dant l'extension .help est un fichier d'aide
(quelque soit la plateforme pour les plus r�cents (� partir Max 4.5).

... sauf que m�me si l'ouverture d'un fichier d'aide pour un objet .mxe
c'est-�-dire �crit pour windows ne pose pas de probl�me sous OSX et
inversement, l'aide qu'il fournit peut concerner parfois une proc�dure
propre � l'environnement windows, et donc source d'erreurs sur OSX et
inversement) ...

Avant de voir la proc�dure d'installation des objets dont nous avons besoin
pour envoyer et r�cup�rer sous Max des donn�es en r�seau,
lire attentivement ce qui suit :

Si vous utilisez une version de Max ant�rieure � la version 4.6, alors vous
devez installer les objets udpreceive et udpsend, que vous trouverez "zipp�s"
pour OSX sous le nom de udp20060126.dmg, et pour windows sous le nom de udp20060126.zip 

dans tout les cas, vous devez installer l'objet OpenSoundControl, qui permet de
formatter les donn�es Max pour les faire transiter par un r�seau. Vous trouverez
OSC et son aide "zipp�s" pour OSX sous le nom OpenSoundControl_1.9.9.tar.gz, et
pour windows sous le nom OpenSoundControl_1.9.9.zip.


proc�dure :

quitter Max/MSP/jitter (si l'application est ouverte).

d�compresser les fichiers dont vous avez besoin

pour Mac :
mettre les fichiers .mxo (les objets) dans un dossier qui se nomme externals
situ� : Applications/MaxMSP4.x/Cycling'74/externals
mettre les fichiers .help (les patches d'aide) dans un dossier nomm� max-help
situ� : Applications/MaxMSP4.x/max-help

pour PC :
les dossiers externals et max-help sont �galement pr�sent sur le disque dur,
mais j'avoue ne pas conna�tre le chemin d'acc�s ...

ensuite (proc�dure commune Mac et PC) :

lancer l'application Max/MSP/jitter

dans le menu file choisir Install, une fen�tre de dialogue s'ouvre.
Aller dans le dossier externals et choisissez un des objets (.mxo ou .mxe en
fonction plateforme) � installer et cliquer sur choose.
R�p�tez l'op�ration autant de fois que vous avez d'objets � installer (on ne
peut installer qu'un objet � la fois).

A chaque installation, regardez dans la fen�tre Max les informations qui s'inscrivent.
Si l'objet s'installe correctement, vous devez avoir infos relatives
� la version de l'objet, le nom de son cr�ateur ... sinon des messages d'erreur.

D�sormais vos objets sont install�s et seront appel�s chaque fois que vous les
cr�erez dans le patcher (la fen�tre dans laquelle vous construisez le patch).
Remarque : si vous changez de version de Max ou de machines, il faudra les r�installer.
Remarque : les fichiers d'aide de ces objets �tant install�s dans max-help, vous
pourrez b�n�ficier du patch d'aide (exemple d'utilisation) comme pour tous les
objets des librairies Max.

------------------------------------------------------------------------

Maintenant vous pouvez ouvrir le fichier AsciiWorld01.mxb ou le fichier AsciiWorld01.txt
(qui est sa version au format texte) et qui se trouve dans le dossier Patches.

remarque : les ports r�seau (de r�ception et d'envoi) sont donn�s � titre indicatif
de m�me pour l'adresse IP d'envoi.

Ouvrez le patch, essayez de bien rep�rer sa logique (aidez vous des aides)

le but est de demander � une machine distante les param�tres d'une image, et de recevoir
ceux-ci et seulement eux.

------------------------------------------------------------------------